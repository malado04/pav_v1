<div id="{{ $chart->id }}">
</div>
@include('charts::loader')