<?php

namespace ConsoleTVs\Charts\Features\C3;

trait Dataset
{
    //
}
