<?php

return [

    /*
    |--------------------------------------------------------------------------
    | IFrame Mode Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the AdminLTE IFrame mode blade
    | layout. You are free to modify these language lines according to your
    | application's requirements.
    |
    */

    'btn_close' => 'Chiudi',
    'btn_close_active' => 'Chiudi scheda',
    'btn_close_all' => 'Chiudi tutto',
    'btn_close_all_other' => 'Chiudi tutto il resto',
    'tab_empty' => 'Nessuna scheda selezionata!',
    'tab_home' => 'Home',
    'tab_loading' => 'Caricamento scheda',
];
