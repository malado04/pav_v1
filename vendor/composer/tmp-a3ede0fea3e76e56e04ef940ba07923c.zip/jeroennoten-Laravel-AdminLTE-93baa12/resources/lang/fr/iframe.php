<?php

return [

    /*
    |--------------------------------------------------------------------------
    | IFrame Mode Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the AdminLTE IFrame mode blade
    | layout. You are free to modify these language lines according to your
    | application's requirements.
    |
    */

    'btn_close' => 'Fermer',
    'btn_close_active' => 'Fermer Actif',
    'btn_close_all' => 'Tout fermer',
    'btn_close_all_other' => 'Fermer tout le reste',
    'tab_empty' => 'Aucun onglet sélectionné !',
    'tab_home' => 'Accueil',
    'tab_loading' => 'Onglet en cours de chargement',

];
